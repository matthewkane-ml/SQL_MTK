FROM gitpod/workspace-postgres
